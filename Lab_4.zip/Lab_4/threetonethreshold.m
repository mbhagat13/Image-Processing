function out = threetonethreshold (input, a, c, b)
if (nargin ~= 4)
        disp ('Input Error');
        return;
else
    %Three Tone
    input =cast(input,'double');
    a =cast(a,'double');
    b =cast(b,'double');
    c =cast(c,'double');
    for x = (1:size(input, 1))
        for y = (1:size(input, 2))
            if (input(x, y) <= max(a, b))
                input(x, y) = 0.5 + 0.25 * (tanh(c * (input(x,y) - a)) + tanh(c * (input(x,y) - b)));
            else
                input(x, y) = 1;
            end
        end
    end
end
out = cast(input,'uint8');
end